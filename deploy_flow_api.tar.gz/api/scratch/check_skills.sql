SELECT id, name, skills FROM Tenant;
