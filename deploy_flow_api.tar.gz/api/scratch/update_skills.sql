UPDATE Tenant SET skills = '{"sales": true, "purchase_approval": true, "queue_management": true}';
