SELECT id, name, phone, tags FROM `Lead` WHERE phone LIKE '%6442221844%';
