import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
    constructor(private reflector: Reflector) { }

    canActivate(context: ExecutionContext): boolean {
        const requiredRoles = this.reflector.get<string[]>('roles', context.getHandler());
        if (!requiredRoles) {
            return true;
        }
        const request = context.switchToHttp().getRequest();
        const user = request.user; // Assumes AuthGuard has populated this

        if (!user) return false;

        // SYSTEM_ADMIN overrides all role checks
        if (user.role === 'SYSTEM_ADMIN') return true;

        return requiredRoles.includes(user.role);
    }
}
